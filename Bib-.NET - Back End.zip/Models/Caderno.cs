﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models
{
    public class Caderno
    {       
        public int Id { get; set; }

        public string Titulo { get; set; }

        public decimal Valor { get; set; }

        public int NrFolhas { get; set; }

        public Caderno()
        {
        }

        public void copiarDados(Models.Caderno caderno)
        {
            this.Titulo = caderno.Titulo;
            this.Valor = caderno.Valor;
            this.NrFolhas = caderno.NrFolhas;
        }
    }
}