﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace web_api.Controllers
{
    public class DocesController : ApiController
    {
        // GET: api/Doces
        public IEnumerable<Models.Doce> Get()
        {
            //return Repositories.Doce.getAll();
            //return Repository_Entity.Doce_Entity.getAll();
            return RepositoriesEntity.Doce.getAll();
        }

        // GET: api/Doces/5
        public Models.Doce Get(int id)
        {
            //return Repositories.Doce.getById(id);
            //return Repository_Entity.Doce_Entity.getById(id);
            return RepositoriesEntity.Doce.getById(id);
        }

        // POST: api/Doces
        public HttpResponseMessage Post([FromBody]Models.Doce doce)
        {
            try
            {
                //Repositories.Doce.save(doce);
                //Repository_Entity.Doce_Entity.save(doce);
                RepositoriesEntity.Doce.save(doce);
                return new HttpResponseMessage(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                Utils.Log.gravar(ex);
                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
        }

        // PUT: api/Doces/5
        public HttpResponseMessage Put(int id, [FromBody]Models.Doce doce)
        {
            try
            {
                doce.Id = id;
                //Repositories.Doce.update(doce);
                //Repository_Entity.Doce_Entity.update(doce);
                RepositoriesEntity.Doce.update(doce);
                return new HttpResponseMessage(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                Utils.Log.gravar(ex);
                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
        }

        // DELETE: api/Doces/5
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                //Repositories.Doce.deleteById(id);
                //Repository_Entity.Doce_Entity.deleteById(id);
                RepositoriesEntity.Doce.deleteById(id);
                return new HttpResponseMessage(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                Utils.Log.gravar(ex);
                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
        }
    }
}
