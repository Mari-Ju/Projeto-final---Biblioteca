﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace web_api.Controllers
{
    public class GibisController : ApiController
    {
        public IHttpActionResult Get()
        {
            List<Models.Gibi> gibis = RepositoriesEntity.Gibi.getAll();
            return Ok(gibis);
        }

        public Models.Gibi Get(int id)
        {
            return RepositoriesEntity.Gibi.getById(id);
        }

        public Models.Gibi Get(string titulo)
        {
            return RepositoriesEntity.Gibi.getByTitulo(titulo);
        }

        public IHttpActionResult Post([FromBody]Models.Gibi gibi)
        {
            try
            {
                RepositoriesEntity.Gibi.save(gibi);
                return Ok();
            }
            catch (Exception ex)
            {
                Utils.Log.gravar(ex);
                return InternalServerError();
            }
        }

        public IHttpActionResult Put(int id, [FromBody]Models.Gibi gibi)
        {
            try
            {
                gibi.Id = id;
                RepositoriesEntity.Gibi.update(gibi);
                return Ok();
            }
            catch (Exception ex)
            {
                Utils.Log.gravar(ex);
                return InternalServerError();
            }
        }
        public IHttpActionResult Delete(int id)
        {
            try
            {
                RepositoriesEntity.Gibi.deleteById(id);
                return Ok();
            }
            catch (Exception ex)
            {
                Utils.Log.gravar(ex);
                return InternalServerError();
            }
        }
    }
}
