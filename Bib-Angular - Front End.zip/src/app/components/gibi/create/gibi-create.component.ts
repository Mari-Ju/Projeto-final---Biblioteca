import { GibiService } from './../../../service/gibi/gibi.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Gibi } from 'src/app/model/gibi';
import { take } from 'rxjs';

@Component({
  selector: 'app-gibi-create',
  templateUrl: './gibi-create.component.html',
  styleUrls: ['./gibi-create.component.css']
})
export class GibiCreateComponent implements OnInit {
  gibi: Gibi;

  constructor(private router: Router, private gibiService: GibiService) {
    console.log("GibiCreateComponent-constructor");
    this.gibi = new Gibi();
   }

  ngOnInit(): void {
  }

  goToIndex(): void{
    console.log("GibiCreateComponent-goToIndex");
    this.router.navigateByUrl("gibi-index");
  }

  post(): void{
    console.log("GibiCreateComponent-create");
    this.gibiService.post(this.gibi)
    .pipe(take(1))
    .subscribe(data => {
      this.gibi = data;
      this.goToIndex();
    });
    console.log("Gibi");
  }

}
