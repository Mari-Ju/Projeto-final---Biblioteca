import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs';
import { Gibi } from 'src/app/model/gibi';
import { GibiService } from 'src/app/service/gibi/gibi.service';

@Component({
  selector: 'app-gibi-edit',
  templateUrl: './gibi-edit.component.html',
  styleUrls: ['./gibi-edit.component.css']
})
export class GibiEditComponent implements OnInit {
  gibi: Gibi;

  constructor(private router: Router, private gibiService: GibiService, private activateRoute: ActivatedRoute) { 
    console.log("GibiEditComponent-constructor");
    this.gibi = new Gibi();
  }

  ngOnInit(): void {
    console.log("GibiEditComponent-ngOnInit");
    const id: number = Number(this.activateRoute.snapshot.paramMap.get("id"));
    console.log("Id = " + id);
    this.getById(id);
  }

  goToIndex(): void {
    this.router.navigateByUrl("gibi-index");
  }

  getById(id: number): void {
    this.gibiService.getById(id)
    .pipe(take(2))
    .subscribe(data => {
      this.gibi = data
    });
    console.log(this.gibi)
  }

  put(): void{
    this.gibiService.put(this.gibi)
    .pipe(take(1))
    .subscribe(() => {
      this.goToIndex();
    });
    console.log("GibiEditComponent-edit-end");
  }

}
