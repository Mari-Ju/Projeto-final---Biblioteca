import { CadernoService } from 'src/app/service/caderno/caderno.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Caderno } from 'src/app/model/caderno';
import { DoceService } from 'src/app/service/doce/doce.service';
import { take } from 'rxjs';

@Component({
  selector: 'app-caderno-edit',
  templateUrl: './caderno-edit.component.html',
  styleUrls: ['./caderno-edit.component.css']
})
export class CadernoEditComponent implements OnInit {
  caderno: Caderno;

  constructor(private router: Router, private activateRoute: ActivatedRoute, private cadernoService: CadernoService){
    this.caderno = new Caderno();
   }

   ngOnInit(): void {
    const id: number = Number (this.activateRoute.snapshot.paramMap.get("id"));
    console.log(id);
    this.getById(id);
  }

  goToIndex(){
    this.router.navigateByUrl("caderno-index");
  }

  getById(id: number){
    this.cadernoService.getById(id)
    .pipe(take(2))
    .subscribe(data => {
      this.caderno = data
    });
    console.log(this.caderno)
  }

  put(): void{
    this.cadernoService.put(this.caderno)
    .pipe(take(1))
    .subscribe()
  }
}
