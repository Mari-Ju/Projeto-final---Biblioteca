import { CadernoService } from 'src/app/service/caderno/caderno.service';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Caderno } from 'src/app/model/caderno';
import { take } from 'rxjs';



@Component({
  selector: 'app-caderno-index',
  templateUrl: './caderno-index.component.html',
  styleUrls: ['./caderno-index.component.css']
})
export class CadernoIndexComponent implements OnInit {
  cadernos: Caderno[] = new Array<Caderno>();
  caderno: Caderno;

  searchId: string;
  searchTitulo: string;

  constructor(private router: Router, private request: HttpClient, private cadernoService: CadernoService) {
    this.caderno = new Caderno();
    this.searchId = "";
    this.searchTitulo = "";
  }

  ngOnInit(): void {
  }

  goToCreate(): void {
    //document.location = "caderno-create";
    this.router.navigateByUrl("caderno-create");
  }

  clearList(): void {
    this.cadernos = [];
  }

  get(): void {
    console.log("CadernoIndexComponent.get");
    console.log("searchId = " + this.searchId);
    console.log("searchTitulo = " + this.searchTitulo);

    this.clearList();

    if (this.searchId !== "") {
      const id: number = Number(this.searchId);
      this.getById(id);
      return;
    }

    if (this.searchTitulo !== "") {
      this.getByTitulo(this.searchTitulo);
      return;
    }

    this.getAll();
  }

  getById(id: number): void {
    console.log("CadernoIndexComponent-getById-start");
    this.cadernoService.getById(id)
      .pipe(
        take(1)
      )
      .subscribe(data => {
        console.log(data);
        if (data != null)
          this.cadernos.push(data);
      });
    console.log("CadernoIndexComponent-getById-end");
  }

  getByTitulo(titulo: string): void {
    console.log("CadernoIndexComponent.getByTitulo-start");
    this.cadernoService.getByTitulo(titulo)
      .subscribe(cadernos => {
        this.cadernos = cadernos;
      });
    console.log(this.cadernos);
    console.log("CadernoIndexComponent.getByTitulo-end");
  }

  getAll(): void {
    console.log("CadernoIndexComponent.getAll-start");
    this.cadernoService.getAll()
      .subscribe(cadernos => {
        this.cadernos = cadernos;
        console.log("Resposta chegou agora:");
        console.log(this.cadernos);
      });
    console.log(this.cadernos);
    console.log("CadernoIndexComponent.getAll-end");
  }

  goToEdit(id: number): void {
    this.router.navigate(["caderno-edit", id]);
  }

  delete(id: number): void {
    console.log("CadernoIndexComponent.delete");
    console.log("Id = " + id);
    this.cadernoService.delete(id)
      .subscribe(() => {
        this.get();
      });
  }
}
