import { DoceService } from 'src/app/service/doce/doce.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Doce } from 'src/app/model/doce';
import { take } from 'rxjs';

@Component({
  selector: 'app-doce-edit',
  templateUrl: './doce-edit.component.html',
  styleUrls: ['./doce-edit.component.css']
})
export class DoceEditComponent implements OnInit {
  doce: Doce;
  constructor(private router: Router, private activateRoute: ActivatedRoute, private doceService: DoceService){
    this.doce = new Doce();
   }

   ngOnInit(): void {
    const id: number = Number (this.activateRoute.snapshot.paramMap.get("id"));
    console.log(id);
    this.getById(id);
  }

  goToIndex(){
    this.router.navigateByUrl("doce-index");
  }

  getById(id: number){
    this.doceService.getById(id)
    .pipe(take(2))
    .subscribe(data => {
      this.doce = data
    });
    console.log(this.doce)
  }

  put(): void{
    this.doceService.put(this.doce)
    .pipe(take(1))
    .subscribe()
  }
}

