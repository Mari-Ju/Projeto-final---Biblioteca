import { DoceService } from 'src/app/service/doce/doce.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Doce } from '../../../model/doce';
import { Component } from "@angular/core";
import { take } from 'rxjs';

@Component({
    selector: 'app-doce-create-component',
    templateUrl: './doce-create.component.html',
    styleUrls: ['doce-create.component.css']
})
export class DoceCreateComponent{
    doce: Doce;

    constructor(private router: Router, private request: HttpClient, private doceService: DoceService){
        this.doce = new Doce;
    }

    goToIndex(){
        this.router.navigateByUrl("doce-index");
    }

    post(): void{
        this.doceService.post(this.doce)
        .pipe(take(1))
        .subscribe((doce) => {
          this.doce = doce;
          console.log("Doce Criado");
          console.log(this.doce);      
        })
      }


}
