import { Injectable } from "@angular/core";
import {HttpClient} from "@angular/common/http"
import { Observable } from "rxjs";
import { Gibi } from "src/app/model/gibi";

@Injectable({
    providedIn: 'root'
})

export class GibiService{
    private uri: string = "https://localhost:44393/api/gibis/";

    constructor(private httpClient: HttpClient){
        console.log("Recebeu a resposta - Gibi.Service");
    }
    getAll(): Observable<Gibi[]> {
        console.log("GibiService.getAll-start");
        return this.httpClient.get<Gibi[]>(this.uri);
    }

    post(gibi: Gibi): Observable<Gibi>{
        console.log("Gibi.Service.save");
        return this.httpClient.post<Gibi>(this.uri,gibi);
    }

    getById(id: number): Observable<Gibi>{
        console.log("Gibi.Service.getById");
        const endpoint: string = this.uri + id;
        return this.httpClient.get<Gibi>(endpoint);
    }

    getByTitulo(descricao: string): Observable<Gibi[]> {
        console.log("DoceService.getByDescricao-start");
        const uri: string = `${this.uri}?descricao=${descricao}`;
        return this.httpClient.get<Gibi[]>(uri);
      }

    delete(id: number): Observable<Gibi>{
        return this.httpClient.delete<Gibi>(this.uri + id);
    }

    put(gibi: Gibi): Observable<Gibi>{
        console.log("put-doce-service-start");
        const uri: string = this.uri + gibi.Id;
        console.log(uri);
        return this.httpClient.put<Gibi>(uri,gibi);
    }


}