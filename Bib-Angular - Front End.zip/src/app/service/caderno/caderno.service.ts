import { Injectable } from "@angular/core";
import {HttpClient} from "@angular/common/http"
import { Observable } from "rxjs";
import { Caderno } from "src/app/model/caderno";

@Injectable({
    providedIn: 'root'
})

export class CadernoService{
    private uri: string = "https://localhost:44393/api/cadernos/";

    constructor(private httpClient: HttpClient){
        console.log("Recebeu a resposta - Caderno.Service");
    }
    getAll(): Observable<Caderno[]> {
        console.log("CadernoService.getAll-start");
        return this.httpClient.get<Caderno[]>(this.uri);
      }

    post(caderno: Caderno): Observable<Caderno>{
        console.log("Caderno.Service.save");
        return this.httpClient.post<Caderno>(this.uri,caderno);
    }

    getById(id: number): Observable<Caderno>{
        console.log("Caderno.Service.getById");
        const endpoint: string = this.uri + id;
        return this.httpClient.get<Caderno>(endpoint);
    }

    getByTitulo(descricao: string): Observable<Caderno[]> {
        console.log("CadernoService.getByDescricao-start");
        const uri: string = `${this.uri}?descricao=${descricao}`;
        return this.httpClient.get<Caderno[]>(uri);
      }

    delete(id: number): Observable<Caderno>{
        return this.httpClient.delete<Caderno>(this.uri + id);
    }

    put(caderno: Caderno): Observable<Caderno>{
        console.log("put-caderno-service-start");
        const uri: string = this.uri + caderno.Id;
        console.log(uri);
        return this.httpClient.put<Caderno>(uri,caderno);
    }



}