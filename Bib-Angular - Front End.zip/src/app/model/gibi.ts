export class Gibi{
    Id!: number;
    Titulo: string;
    Valor: number;
    Genero: string;
    NrPaginas: number;
    Editora: string;
    AnoEdicao: number;

    constructor(){
        this.Titulo = "";
        this.Valor = 0;
        this.Genero = "";
        this.NrPaginas = 0;
        this.Editora = "";
        this.AnoEdicao = 0;
    }
}